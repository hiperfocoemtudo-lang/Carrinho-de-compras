#!/usr/bin/python3
"""Carrinho: a persistent native multi-file drag shelf for Cinnamon/X11."""
import gi
gi.require_version('Gtk', '3.0')
gi.require_version('Gdk', '3.0')
from gi.repository import Gtk, Gdk, GdkPixbuf, Gio, GLib
import cairo
import math
import os
import json
import time
import shutil
import threading
import sys
from pathlib import Path
from urllib.parse import urlparse, unquote
from Xlib import X, XK, display

ROOT = Path(__file__).resolve().parent
STATE = Path(os.environ.get('XDG_STATE_HOME', Path.home()/'.local/state'))/'carrinho-y2k/items.json'
from settings_ui import SettingsWindow, load as load_settings, item_layout, items_icon_state
PREFS=load_settings()
URI, XDS = 1, 2

def local_path(uri):
    p = urlparse(uri)
    if p.scheme != 'file' or p.netloc not in ('', 'localhost'):
        return None
    return Path(os.path.abspath(unquote(p.path)))

def save_items(items):
    STATE.parent.mkdir(parents=True, exist_ok=True)
    temp = STATE.with_suffix('.tmp')
    temp.write_text(json.dumps([str(p) for p in items], ensure_ascii=False))
    temp.replace(STATE)

def transfer_items(items, destination, move=False):
    """Never overwrite. Keep failed entries; return successful paths and errors."""
    destination = Path(destination).resolve()
    if not destination.is_dir():
        return [], ['A pasta de destino não existe.']
    done, errors = [], []
    # A parent folder already includes its children.
    selected = [p for p in items if not any(q != p and q.is_dir() and q in p.parents for q in items)]
    for source in selected:
        try:
            if not source.exists():
                raise ValueError('arquivo não encontrado')
            if source.parent.resolve() == destination:
                raise ValueError('o item já está nesta pasta')
            if source.is_dir() and (destination == source.resolve() or source.resolve() in destination.parents):
                raise ValueError('não é possível colocar uma pasta dentro dela mesma')
            target = destination/source.name
            n = 2
            while target.exists() or target.is_symlink():
                target = destination/f'{source.stem} ({n}){source.suffix}'
                n += 1
            if move:
                shutil.move(str(source), str(target))
            elif source.is_dir():
                shutil.copytree(source, target, symlinks=True)
            else:
                shutil.copy2(source, target, follow_symlinks=False)
            done.extend(p for p in items if p == source or source in p.parents)
        except Exception as exc:
            errors.append(f'{source.name}: {exc}')
    return list(dict.fromkeys(done)), errors

import hashlib
from collections import deque

# Original collage asset, painted directly with its existing transparency.
S = .75
COMPACT_W, COMPACT_H = 156, 156
GRID_W, CELL_W, CELL_H = 350, 66, 78
ART_SIZE = 150
_ART = None

def collage(cr, front=False, expanded=False, wheel_angle=0.):
    global _ART
    if _ART is None:_ART=GdkPixbuf.Pixbuf.new_from_file(PREFS['image'] or str(ROOT/'assets/cart.png'))
    if PREFS['image']:
        if front:return
        # Match the settings preview: preserve aspect ratio and center the
        # complete original image, including its transparent margins.
        factor=min(ART_SIZE/_ART.get_width(),ART_SIZE/_ART.get_height())
        cr.save()
        cr.translate((ART_SIZE-_ART.get_width()*factor)/2,(ART_SIZE-_ART.get_height()*factor)/2)
        cr.scale(factor,factor)
        Gdk.cairo_set_source_pixbuf(cr,_ART,0,0);cr.paint();cr.restore();return
    cr.save()
    cr.scale(ART_SIZE/_ART.get_width(),ART_SIZE/_ART.get_height())
    if not front:
        cr.rectangle(0,0,1024,1024)
        cr.rectangle(710,40,240,240)
        cr.rectangle(787,510,213,235)
        cr.set_fill_rule(cairo.FILL_RULE_EVEN_ODD);cr.clip()
    if front:
        cr.move_to(140,394);cr.line_to(785,394);cr.line_to(700,702);cr.line_to(250,702);cr.close_path();cr.clip()
        Gdk.cairo_set_source_pixbuf(cr,_ART,0,0);cr.paint()
    else:
        wheels=((249,826,174,158),(553,826,172,158))
        rotating=abs(math.remainder(wheel_angle,math.tau))>1e-8
        cr.save()
        cr.rectangle(0,0,1024,1024)
        if expanded:cr.rectangle(787,510,213,235)
        if rotating:
            for x,y,w,h in wheels:cr.rectangle(x,y,w,h)
        cr.set_fill_rule(cairo.FILL_RULE_EVEN_ODD);cr.clip()
        Gdk.cairo_set_source_pixbuf(cr,_ART,0,0);cr.paint()
        cr.restore()
        if rotating:
            for x,y,w,h in wheels:
                # Isolate each original flower in a temporary drawing group.
                # Rotate the group around its own axle, leaving the body still.
                cr.push_group()
                cr.save();cr.rectangle(x,y,w,h);cr.clip()
                Gdk.cairo_set_source_pixbuf(cr,_ART,0,0);cr.paint();cr.restore()
                wheel=cr.pop_group()
                cx,cy=x+w/2,y+h/2
                cr.save();cr.translate(cx,cy);cr.rotate(wheel_angle);cr.translate(-cx,-cy)
                cr.set_source(wheel);cr.paint();cr.restore()
        if expanded:
            cr.save();cr.rectangle(787,510,213,235);cr.clip()
            cr.translate(893.5,627.5);cr.rotate(math.pi);cr.translate(-893.5,-627.5)
            Gdk.cairo_set_source_pixbuf(cr,_ART,0,0);cr.paint();cr.restore()
    cr.restore()

CSS = b'''
window { background: transparent; }
.floating-action { background-image: none; background-color: #ffffff; color: #243747; font-family: Sans; font-size: 13px; font-weight: 600; border: 1px solid #d7e6ee; border-radius: 20px; min-height: 42px; padding: 4px 20px; box-shadow: 0 5px 12px alpha(#172838, .22); }
.floating-action:hover { background-color: #e9f9ff; border-color: #34b9e4; }
.floating-action.move:hover { background-color: #effbf2; border-color: #58bd7c; }
.floating-action:disabled { color: #748591; }
.floating-close { background-image: none; background-color: #ffffff; color: #e34b56; border: 1px solid #f4d7dc; border-radius: 16px; min-width: 26px; min-height: 26px; padding: 0; box-shadow: 0 3px 8px alpha(#172838,.18); }
menu { background: #ffffff; color: #203548; }
menuitem { padding: 8px 14px; }
menuitem:hover { background: #e5f7ff; }
dialog { background: #f8fbfd; color: #203548; }
'''

def polygon(cr, points, fill, stroke=None, width=3):
    cr.move_to(*points[0])
    for point in points[1:]: cr.line_to(*point)
    cr.close_path()
    cr.set_source_rgba(*fill)
    cr.fill_preserve()
    if stroke:
        cr.set_source_rgba(*stroke); cr.set_line_width(width); cr.stroke()
    else: cr.new_path()

class FloatingChoice(Gtk.Window):
    """Two actual GTK buttons on a transparent window, with no dialog panel."""
    def __init__(self, cart, destination, items):
        super().__init__(title='Copiar ou mover')
        self.cart, self.destination, self.items = cart, destination, list(items)
        self.set_decorated(False); self.set_resizable(False); self.set_keep_above(True)
        self.stick()
        self.set_skip_taskbar_hint(True); self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_transient_for(cart); self.set_app_paintable(True)
        visual=self.get_screen().get_rgba_visual()
        if visual: self.set_visual(visual)
        self.connect('draw',Cart.clear_background)
        row=Gtk.Box(spacing=12);row.set_border_width(14);self.add(row)
        self.buttons=[]
        for label,move in [('⧉  Copiar',False),('↗  Mover',True)]:
            button=Gtk.Button(label=label)
            button.get_style_context().add_class('floating-action')
            if move:button.get_style_context().add_class('move')
            button.set_tooltip_text(f'{len(items)} itens → {destination}')
            button.connect('clicked',self.choose,move);row.pack_start(button,False,False,0)
            self.buttons.append(button)
        cancel=Gtk.Button(label='×');cancel.set_valign(Gtk.Align.CENTER)
        cancel.get_style_context().add_class('floating-close')
        cancel.set_tooltip_text('Cancelar esta entrega')
        cancel.connect('clicked',lambda *a:self.destroy());row.pack_end(cancel,False,False,0)
        self.connect('key-press-event',lambda w,e:self.destroy() if e.keyval==Gdk.KEY_Escape else False)
        self.show_all()
        _,x,y=Gdk.Display.get_default().get_default_seat().get_pointer().get_position()
        monitor=Gdk.Display.get_default().get_monitor_at_point(x,y)
        rect=monitor.get_workarea();width,height=self.get_size()
        self.move(max(rect.x+8,min(x-width//2,rect.x+rect.width-width-8)),max(rect.y+55,min(y+12,rect.y+rect.height-height-8)))
        self.present()

    def choose(self,button,move):
        if self.cart.busy:return
        self.cart.start_transfer(self.destination,self.items,move)
        self.destroy()

class Cart(Gtk.ApplicationWindow):
    def __init__(self, app, visible=True):
        super().__init__(application=app,title='Carrinho Y2K')
        self.set_decorated(False);self.set_resizable(False);self.set_keep_above(True)
        self.stick()
        self.set_skip_taskbar_hint(True);self.set_skip_pager_hint(True)
        self.set_type_hint(Gdk.WindowTypeHint.UTILITY);self.set_accept_focus(False)
        self.set_app_paintable(True)
        visual=self.get_screen().get_rgba_visual()
        if visual:self.set_visual(visual)
        self.connect('draw',self.clear_background)
        self.items=[]
        try:self.items=list(dict.fromkeys(Path(p) for p in json.loads(STATE.read_text())))
        except (OSError,ValueError):pass
        self.icons={};self.incoming={};self.expanded=False;self.expand=0.;self.expand_target=0.
        self.dragging=False;self.snapshot=[];self.busy=False;self.pending=None
        self.birth=time.monotonic();self.entry_started=None;self.scene_offset=COMPACT_W+28;self.expand_started=0.;self.expand_from=0.;self.scroll=0;self.hitboxes=[];self.pressed=None;self.hover=None
        self.status='';self.status_until=0
        self.area=Gtk.DrawingArea();self.add(self.area)
        self.area.set_size_request(COMPACT_W,COMPACT_H)
        self.area.add_events(Gdk.EventMask.BUTTON_PRESS_MASK|Gdk.EventMask.BUTTON_RELEASE_MASK|Gdk.EventMask.POINTER_MOTION_MASK|Gdk.EventMask.SCROLL_MASK|Gdk.EventMask.LEAVE_NOTIFY_MASK)
        self.area.connect('draw',self.draw_scene)
        self.area.connect('button-press-event',self.press)
        self.area.connect('button-release-event',self.release)
        self.area.connect('motion-notify-event',self.motion)
        self.area.connect('scroll-event',self.on_scroll)
        self.area.connect('leave-notify-event',self.leave)
        self.targets=Gtk.TargetList.new([Gtk.TargetEntry.new('XdndDirectSave0',0,XDS),Gtk.TargetEntry.new('text/uri-list',0,URI)])
        self.area.connect('drag-begin',self.drag_begin)
        self.area.connect('drag-data-get',self.drag_data)
        self.area.connect('drag-end',self.drag_end)
        self.area.connect('drag-failed',lambda *a:True)
        self.area.drag_dest_set(Gtk.DestDefaults(0),[Gtk.TargetEntry.new('text/uri-list',0,URI)],Gdk.DragAction.COPY)
        self.area.connect('drag-data-received',self.receive)
        self.area.connect('drag-motion',self.drag_motion)
        self.area.connect('drag-drop',self.drop)
        self.connect('delete-event',lambda *a:self.cancel_cart() or True)
        self.connect('key-press-event',self.key_press)
        self.area.show()
        self.layout()
        if visible:self.show()
        GLib.timeout_add(16,self.tick)

    @staticmethod
    def clear_background(widget,cr):
        cr.set_operator(cairo.OPERATOR_SOURCE);cr.set_source_rgba(0,0,0,0);cr.paint()
        cr.set_operator(cairo.OPERATOR_OVER)
        return False

    def workarea(self):
        pointer=Gdk.Display.get_default().get_default_seat().get_pointer()
        _,x,y=pointer.get_position()
        return Gdk.Display.get_default().get_monitor_at_point(x,y).get_workarea()

    def layout(self):
        rect=self.workarea()
        self.right=rect.x+rect.width-22
        self.top=rect.y+62
        self.maxheight=max(180,rect.height-90)
        self.set_dimensions()

    def set_dimensions(self):
        # Fixed transparent canvas: expanding never resizes or relocates the cart.
        width,height=GRID_W,self.maxheight
        changed=getattr(self,'width',None)!=width or getattr(self,'height',None)!=height
        self.width,self.height=width,height
        self.cart_x=width-COMPACT_W
        if changed:
            self.area.set_size_request(width,height)
            self.resize(width,height)
        self.move(self.right-width,self.top)

    def reveal(self,toggle=True):
        if self.is_visible() and toggle:self.hide();return
        if not self.is_visible():
            self.entry_started=None
            self.scene_offset=COMPACT_W+28
            self.layout()
            self.show()
        self.set_keep_above(True)

    def update_motion(self,now):
        # Start the clock on the first paint: no visible frame at the final spot.
        p=0. if self.entry_started is None else max(0.,min(1.,(now-self.entry_started)/PREFS['duration']))
        mode=PREFS['animation']
        self.scene_offset=(COMPACT_W+28)*(1-p)**3 if mode=='slide' else 0.
        self.entry_progress=p
        self.set_opacity(p if mode=='fade' else 1.)
        if self.expand!=self.expand_target:
            t=max(0.,min(1.,(now-self.expand_started)/.58))
            eased=t*t*(3-2*t)
            self.expand=self.expand_from+(self.expand_target-self.expand_from)*eased
            if t==1:self.expand=self.expand_target

    def tick(self):
        if not self.is_visible():return True
        now=time.monotonic()
        self.update_motion(now)
        self.incoming={p:t for p,t in self.incoming.items() if now-t<.9}
        self.area.queue_draw()
        return True

    def update_input_region(self):
        window=self.get_window()
        if not window:return
        region=cairo.Region()
        offset=round(self.scene_offset)
        def add(x,y,w,h):
            left=max(0,int(x+offset));top=max(0,int(y))
            right=min(self.width,int(x+offset+w));bottom=min(self.height,int(y+h))
            if right>left and bottom>top:region.union(cairo.RectangleInt(left,top,right-left,bottom-top))
        add(self.cart_x+2,2,ART_SIZE+8,ART_SIZE+8)
        for pkey,skey in [('cancel_position','cancel_size'),('items_position','items_size')]:
            px,py=PREFS[pkey];size=float(PREFS[skey])+6
            add(self.cart_x+px*ART_SIZE-size/2,py*ART_SIZE-size/2,size,size)
        if self.expanded or self.expand>0:
            for index,path in enumerate(self.items):
                x,y,size,angle=self.item_pose(path,index)
                if y+size>=145 and y<self.height:add(x-5,max(145,y-5),max(64,size+10),80)
                if self.expand==1:
                    tx,ty=self.grid_position(index)
                    if ty+CELL_H>145 and ty<self.height:add(tx, max(145,ty-5),64,CELL_H)
            add(self.width-11,145,11,self.height-145)
        window.input_shape_combine_region(region,0,0)

    def icon(self,path,size=48):
        key=(str(path),size)
        if key not in self.icons:
            try:
                if path.suffix.lower() in ('.png','.jpg','.jpeg','.webp'):
                    pix=GdkPixbuf.Pixbuf.new_from_file_at_scale(str(path),size,size,True)
                else:
                    info=Gio.File.new_for_path(str(path)).query_info('standard::icon',Gio.FileQueryInfoFlags.NONE,None)
                    pix=Gtk.IconTheme.get_default().lookup_by_gicon(info.get_icon(),size,0).load_icon()
            except Exception:pix=Gtk.IconTheme.get_default().load_icon('text-x-generic',size,0)
            self.icons[key]=pix
        return self.icons[key]

    def paint_icon(self,cr,path,x,y,size,angle=0,alpha=1):
        pix=self.icon(path);cr.save();cr.translate(x+size/2,y+size/2);cr.rotate(angle)
        w,h=pix.get_width(),pix.get_height();scale=size/max(w,h)
        cr.scale(scale,scale);Gdk.cairo_set_source_pixbuf(cr,pix,-w/2,-h/2);cr.paint_with_alpha(alpha);cr.restore()

    def pile(self,path,index):
        x,y,size,angle=item_layout(PREFS,path,index)
        return self.cart_x+x,y,size,angle

    def grid_position(self,index):
        return 10+(index%5)*CELL_W,COMPACT_H+4+(index//5)*CELL_H-self.scroll

    def rounded(self,cr,x,y,w,h,r,color):
        cr.new_sub_path()
        for cx,cy,start in [(x+w-r,y+r,-math.pi/2),(x+w-r,y+h-r,0),(x+r,y+h-r,math.pi/2),(x+r,y+r,math.pi)]:cr.arc(cx,cy,r,start,start+math.pi/2)
        cr.close_path();cr.set_source_rgba(*color);cr.fill()

    def label(self,cr,text,x,y,size=10,color=(.18,.25,.30,1),center=False):
        cr.select_font_face('Sans',cairo.FONT_SLANT_NORMAL,cairo.FONT_WEIGHT_NORMAL);cr.set_font_size(size)
        if center:x-=cr.text_extents(text).width/2
        cr.set_source_rgba(*color);cr.move_to(x,y);cr.show_text(text)

    def item_pose(self,path,index):
        x,y,size,angle=self.pile(path,index)
        tx,ty=self.grid_position(index)
        q=self.expand
        x+=(tx+11-x)*q
        y+=(ty+4-y)*q
        size+=(PREFS['item_size']-size)*q
        angle*=1-q
        start=self.incoming.get(path)
        if start and q==0:
            t=min(1,max(0,(time.monotonic()-start)/.8))
            rest=(1-t)**3
            y-=65*rest;x+=25*rest;size+=10*rest
        return x,y,size,angle

    def draw_scene(self,widget,cr):
        now=time.monotonic()
        if self.entry_started is None:self.entry_started=now
        self.update_motion(now)
        self.hitboxes=[]
        cr.save()
        cr.translate(self.scene_offset,0)
        if PREFS['animation']=='rise':cr.translate(0,55*(1-self.entry_progress)**3)
        if PREFS['animation']=='zoom':
            scale=.65+.35*(1-(1-self.entry_progress)**3)
            cx=self.cart_x+ART_SIZE/2;cy=ART_SIZE/2
            cr.translate(cx,cy);cr.scale(scale,scale);cr.translate(-cx,-cy)
        cr.save();cr.translate(self.cart_x,0);collage(cr,expanded=self.expanded,wheel_angle=-2*math.tau*(1-self.scene_offset/(COMPACT_W+28)));cr.restore()
        poses=[]
        for index,path in enumerate(self.items):
            if self.expand==0 and index<max(0,len(self.items)-24):continue
            x,y,size,angle=self.item_pose(path,index)
            if y+size<0 or y>self.height:continue
            poses.append((path,x,y,size,angle))
        # Two disjoint clips maintain depth without duplicating moving icons.
        cr.save();cr.rectangle(0,0,self.width,ART_SIZE*110/150 if not PREFS['image'] else self.height);cr.clip()
        for path,x,y,size,angle in poses:self.paint_icon(cr,path,x,y,size,angle)
        cr.restore()
        cr.save();cr.translate(self.cart_x,0);collage(cr,front=True);cr.restore()
        cr.save();cr.rectangle(0,ART_SIZE*110/150,self.width,self.height-ART_SIZE*110/150);cr.clip()
        for path,x,y,size,angle in poses:
            if not PREFS['image']:self.paint_icon(cr,path,x,y,size,angle)
        cr.restore()
        if self.expand==1:
            cr.save();cr.rectangle(0,145,self.width,self.height-COMPACT_H);cr.clip()
            for index,path in enumerate(self.items):
                tx,ty=self.grid_position(index)
                if ty+CELL_H<145 or ty>self.height:continue
                self.rounded(cr,tx,ty+PREFS['item_size']+9,CELL_W-5,18,8,(1,1,1,.90))
                name=path.name if path.exists() else '⚠ '+path.name
                if len(name)>9:name=name[:8]+'…'
                self.label(cr,name,tx+CELL_W/2,ty+PREFS['item_size']+22,9,(.16,.22,.29,1),True)
                cx,cy=tx+11+PREFS['item_size']-1,ty+7
                cr.arc(cx,cy,8,0,math.tau);cr.set_source_rgba(1,1,1,1);cr.fill()
                cr.set_line_width(1.5);cr.set_source_rgba(.90,.20,.25,1)
                cr.move_to(cx-2.5,cy-2.5);cr.line_to(cx+2.5,cy+2.5);cr.move_to(cx+2.5,cy-2.5);cr.line_to(cx-2.5,cy+2.5);cr.stroke()
                if 145<=cy<=self.height:self.hitboxes.append((cx-10,cy-10,20,20,('remove',path)))
            cr.restore()
            total=math.ceil(len(self.items)/5)*CELL_H
            view=self.height-COMPACT_H
            if total>view:
                thumb=max(25,view*view/total);y=150+(view-thumb)*self.scroll/max(1,total-view)
                self.rounded(cr,self.width-7,y,4,thumb,2,(.15,.72,.86,.8))
        for key,pkey,skey,crop,action in [
            ('cancel_icon','cancel_position','cancel_size',(710,40,240,240),'quit'),
            ('items_icon','items_position','items_size',(787,510,213,235),'toggle')]:
            size=float(PREFS[skey]);px,py=PREFS[pkey]
            x=self.cart_x+px*ART_SIZE;y=py*ART_SIZE
            try:
                path=PREFS[key];rotate=False
                if key=='items_icon':path,rotate=items_icon_state(PREFS,self.expanded)
                cache_key=('control',key,path)
                if cache_key not in self.icons:
                    self.icons[cache_key]=GdkPixbuf.Pixbuf.new_from_file(path) if path else GdkPixbuf.Pixbuf.new_from_file(str(ROOT/'assets/cart.png')).new_subpixbuf(*crop)
                pix=self.icons[cache_key]
                cr.save();cr.translate(x,y)
                if rotate:cr.rotate(math.pi)
                factor=size/max(pix.get_width(),pix.get_height());cr.scale(factor,factor)
                Gdk.cairo_set_source_pixbuf(cr,pix,-pix.get_width()/2,-pix.get_height()/2);cr.paint();cr.restore()
            except Exception:pass
            self.hitboxes.append((x-size/2-3,y-size/2-3,size+6,size+6,(action,None)))
        if self.items:
            self.rounded(cr,self.cart_x+90,125,28,15,7,(1,1,1,.96))
            self.label(cr,str(len(self.items)),self.cart_x+104,136,9,(.05,.45,.58,1),True)
        if self.busy:
            self.rounded(cr,self.cart_x+13,129,104,15,6,(1,1,1,.96))
            self.label(cr,'Transferindo…',self.cart_x+65,140,9,center=True)
        cr.restore()
        self.update_input_region()
        return False

    def action_at(self,x,y):
        x-=self.scene_offset
        for hx,hy,w,h,action in reversed(self.hitboxes):
            if hx<=x<=hx+w and hy<=y<=hy+h:return action
        return None

    def press(self,widget,event):
        if event.button==3:self.menu();return True
        if event.button!=1:return False
        self.pressed=(event.x,event.y,self.action_at(event.x,event.y))
        return True

    def release(self,widget,event):
        pressed=self.pressed;self.pressed=None
        if not pressed or self.dragging:return True
        action=self.action_at(event.x,event.y)
        if action and pressed[2]==action:
            if action[0]=='quit':
                if not self.busy:self.cancel_cart()
                else:self.message('Aguarde a transferência terminar.')
            elif action[0]=='toggle':self.manage()
            elif action[0]=='remove':self.remove(action[1])
        return True

    def motion(self,widget,event):
        action=self.action_at(event.x,event.y)
        tooltip={'quit':'Encerrar carrinho','toggle':'Recolher itens' if self.expanded else 'Abrir itens'}
        self.area.set_tooltip_text(tooltip.get(action[0]) if action else ('Arraste o carrinho para entregar os arquivos' if self.items else 'Arraste arquivos para a cesta'))
        if self.pressed and not self.pressed[2] and event.state&Gdk.ModifierType.BUTTON1_MASK and not self.dragging and not self.busy:
            x,y,_=self.pressed
            if math.hypot(event.x-x,event.y-y)>8 and x-self.scene_offset>=self.cart_x and y<COMPACT_H:
                self.snapshot=[p for p in self.items if p.exists()]
                self.pressed=None
                if self.snapshot:
                    self.dragging=True
                    self.area.drag_begin_with_coordinates(self.targets,Gdk.DragAction.COPY|Gdk.DragAction.MOVE|Gdk.DragAction.ASK,1,event,-1,-1)
        return False

    def leave(self,*args):return False

    def on_scroll(self,widget,event):
        if not self.expanded:return False
        maximum=max(0,math.ceil(len(self.items)/5)*CELL_H-(self.height-COMPACT_H))
        if event.direction==Gdk.ScrollDirection.UP:delta=-45
        elif event.direction==Gdk.ScrollDirection.DOWN:delta=45
        else:delta=event.get_scroll_deltas()[2]*30
        self.scroll=max(0,min(maximum,self.scroll+delta));return True

    def manage(self,*args):
        self.update_motion(time.monotonic())
        self.expanded=not self.expanded
        self.expand_from=self.expand
        self.expand_target=1. if self.expanded else 0.
        self.expand_started=time.monotonic()
        self.incoming.clear()
        self.area.queue_draw()

    def remove(self,path):
        if self.busy:return
        self.items=[p for p in self.items if p!=path];save_items(self.items)
        self.icons={k:v for k,v in self.icons.items() if k[0]!=str(path)}
        self.scroll=min(self.scroll,max(0,math.ceil(len(self.items)/5)*CELL_H-(self.height-COMPACT_H)))
        self.set_dimensions()

    def message(self,text,seconds=5):
        self.status=text;self.status_until=time.monotonic()+seconds
        self.area.set_tooltip_text(text)

    def valid_drop(self,x,y):return self.cart_x+10<=x-self.scene_offset<=self.cart_x+ART_SIZE and 5<=y<=ART_SIZE and not self.busy and not self.dragging

    def drag_motion(self,widget,context,x,y,timestamp):
        valid=self.valid_drop(x,y)
        Gdk.drag_status(context,Gdk.DragAction.COPY if valid else Gdk.DragAction(0),timestamp)
        return valid

    def drop(self,widget,context,x,y,timestamp):
        if not self.valid_drop(x,y):return False
        widget.drag_get_data(context,Gdk.Atom.intern('text/uri-list',False),timestamp)
        return True

    def receive(self,widget,context,x,y,data,info,timestamp):
        if self.busy:Gtk.drag_finish(context,False,False,timestamp);return
        added=0
        for uri in data.get_uris() or []:
            p=local_path(uri)
            if p and p.exists() and p not in self.items:
                self.items.append(p);self.incoming[p]=time.monotonic()+min(added*.05,.3);added+=1
        save_items(self.items);self.set_dimensions()
        self.message(f'{added} itens adicionados • {len(self.items)} na cesta')
        Gtk.drag_finish(context,True,False,timestamp)

    def drag_begin(self,widget,context):
        self.dragging=True
        pix=GdkPixbuf.Pixbuf.new_from_file_at_scale(str(ROOT/'assets/cart.png'),82,82,True)
        Gtk.drag_set_icon_pixbuf(context,pix,40,40)
        try:
            self.xdisplay=display.Display()
            self.xwindow=self.xdisplay.create_resource_object('window',context.get_source_window().get_xid())
            self.xds_atom=self.xdisplay.intern_atom('XdndDirectSave0')
            self.xwindow.change_property(self.xds_atom,self.xdisplay.intern_atom('text/plain'),8,b'Carrinho')
            self.xdisplay.flush()
        except Exception as exc:print('XDS:',exc,flush=True)

    def drag_data(self,widget,context,data,info,timestamp):
        if info==URI:data.set_uris([p.as_uri() for p in self.snapshot])
        elif info==XDS:
            try:
                prop=self.xwindow.get_full_property(self.xds_atom,X.AnyPropertyType)
                path=local_path(bytes(prop.value).decode().rstrip('\0'))
                if not path:raise ValueError('Destino não local')
                data.set(Gdk.Atom.intern('XdndDirectSave0',False),8,b'S')
                GLib.idle_add(self.ask_transfer,path.parent,list(self.snapshot))
            except Exception as exc:
                data.set(Gdk.Atom.intern('XdndDirectSave0',False),8,b'E')
                self.message('Não foi possível identificar a pasta');print(exc,flush=True)

    def drag_end(self,*args):
        self.dragging=False;self.pressed=None
        if hasattr(self,'xdisplay'):
            try:self.xwindow.delete_property(self.xds_atom);self.xdisplay.flush();self.xdisplay.close()
            except Exception:pass
        self.message('Itens mantidos na cesta')

    def ask_transfer(self,destination,items):
        if self.busy:return False
        if self.pending:
            try:self.pending.destroy()
            except Exception:pass
        self.pending=FloatingChoice(self,destination,items)
        return False

    def start_transfer(self,destination,items,move):
        self.busy=True
        def work():
            done,errors=transfer_items(items,destination,move)
            GLib.idle_add(self.transfer_finished,done,errors)
        threading.Thread(target=work,daemon=True).start()

    def transfer_finished(self,done,errors):
        self.busy=False;self.items=[p for p in self.items if p not in done];save_items(self.items);self.set_dimensions()
        if errors:
            d=Gtk.MessageDialog(transient_for=self,modal=True,message_type=Gtk.MessageType.WARNING,buttons=Gtk.ButtonsType.CLOSE,text='Alguns itens ficaram na cesta')
            d.format_secondary_text('\n'.join(errors));d.connect('response',lambda w,r:w.destroy());d.show_all()
        return False

    def choose_folder(self,*args):
        d=Gtk.FileChooserDialog(title='Entregar nesta pasta',transient_for=self,action=Gtk.FileChooserAction.SELECT_FOLDER)
        d.add_buttons('Cancelar',Gtk.ResponseType.CANCEL,'Escolher',Gtk.ResponseType.OK)
        def chosen(widget,response):
            if response==Gtk.ResponseType.OK:self.ask_transfer(Path(widget.get_filename()),list(self.items))
            widget.destroy()
        d.connect('response',chosen);d.show_all()

    def key_press(self,widget,event):
        if event.keyval==Gdk.KEY_Escape:self.hide();return True
        return False

    def menu(self,*args):
        m=Gtk.Menu()
        entries=[('Entregar em uma pasta…',self.choose_folder),('Esvaziar referências',self.empty),('Ocultar',lambda *a:self.hide()),('Cancelar e encerrar',self.cancel_cart)]
        for text,fn in entries:
            item=Gtk.MenuItem(label=text);item.connect('activate',fn);m.append(item)
        m.show_all();m.popup_at_pointer(None)

    def cancel_cart(self,*args):
        if self.busy:
            self.message('Aguarde a transferência terminar.')
            return
        self.items.clear()
        self.incoming.clear()
        self.snapshot.clear()
        self.icons.clear()
        save_items([])
        if self.pending:
            self.pending.destroy()
            self.pending=None
        app=self.get_application()
        settings=getattr(app,'settings_window',None)
        if settings is not None and settings.get_visible():
            self.expanded=False
            self.expand=self.expand_target=0.
            self.scroll=0
            self.pressed=None
            self.hide()
        else:
            app.quit()

    def empty(self,*args):
        if self.busy:return
        self.items=[];save_items(self.items);self.set_dimensions()

class Application(Gtk.Application):
    def __init__(self):
        super().__init__(application_id='local.carrinho.y2k',flags=Gio.ApplicationFlags.HANDLES_COMMAND_LINE)
        self.window=None
        self.apply_settings(PREFS)

    def do_activate(self):self.show_settings()

    def show_settings(self):
        if not hasattr(self,'settings_window'):
            self.settings_window=SettingsWindow(self,PREFS,ROOT/'assets/cart.png',self.apply_settings)
        self.settings_window.show();self.settings_window.present()

    def apply_settings(self,values):
        global PREFS,_ART,ART_SIZE,COMPACT_W,COMPACT_H,GRID_W,CELL_W,CELL_H
        PREFS=dict(values);_ART=None
        ART_SIZE=int(PREFS['cart_size']);COMPACT_W=ART_SIZE+12;COMPACT_H=ART_SIZE+6;CELL_W=max(66,int(PREFS['item_size'])+24);CELL_H=max(78,int(PREFS['item_size'])+38);GRID_W=max(350,COMPACT_W+24,CELL_W*5+20)
        if self.window:
            self.window.icons.clear();self.window.layout();self.window.area.queue_draw()


    def do_command_line(self,command):
        args=command.get_arguments()[1:]
        if '--quit' in args:self.quit();return 0
        if '--settings' in args or not args:self.show_settings()
        else:self.activate_cart('background' if '--background' in args else 'show' if '--show' in args else 'toggle')
        return 0

    def activate_cart(self,mode):
        if self.window:
            if mode!='background':self.window.reveal(toggle=mode=='toggle')
            return
        provider=Gtk.CssProvider();provider.load_from_data(CSS)
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(),provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.window=Cart(self,visible=mode!='background');self.hold()
        self.tray=Gtk.StatusIcon.new_from_file(str(ROOT/'assets/cart.png'))
        self.tray.set_tooltip_text('Carrinho • Ctrl + Super + C')
        self.tray.connect('activate',lambda *a:self.window.reveal())
        self.tray.connect('popup-menu',lambda *a:self.window.menu())

if __name__=='__main__':raise SystemExit(Application().run(sys.argv))
