#!/bin/sh
set -eu
systemctl --user import-environment DISPLAY XAUTHORITY DBUS_SESSION_BUS_ADDRESS XDG_CURRENT_DESKTOP 2>/dev/null || true
systemctl --user start carrinho-gestos.service
