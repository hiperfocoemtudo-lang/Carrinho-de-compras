import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import settings_ui as settings

class PresetsTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.original=settings.CONFIG
  settings.CONFIG=Path(self.temp.name)/'settings.json'
 def tearDown(self):
  settings.CONFIG=self.original;self.temp.cleanup()
 def test_factory_presets_have_all_options_and_assets(self):
  presets=settings.builtin_presets()
  self.assertEqual(set(presets),{'Carrinho de compras','Steeve'})
  for name,preset in presets.items():
   self.assertEqual(set(preset),set(settings.DEFAULTS))
   for key in ('image','cancel_icon','items_icon','items_open_icon'):
    if preset[key]:self.assertTrue(Path(preset[key]).is_file(),name+' '+key)
 def test_shipped_json_has_no_personal_absolute_paths(self):
  root=Path(settings.__file__).resolve().parent
  raw=json.loads((root/'presets.json').read_text())
  for preset in raw['presets'].values():
   for key in ('image','cancel_icon','items_icon','items_open_icon'):
    self.assertTrue(not preset[key] or preset[key].startswith('@assets/'))
 def test_clean_user_gets_packaged_steeve(self):
  expected=settings.builtin_presets()
  data=settings.read_presets({'not':'a preset'})
  self.assertEqual(data['active'],'Steeve')
  self.assertEqual(data['presets'],expected)
  self.assertEqual(settings.load(),expected['Steeve'])
 def test_user_changes_survive_reading_factory_defaults(self):
  data=settings.read_presets();data['presets']['Minha versão']=copy.deepcopy(settings.DEFAULTS)
  data['presets']['Minha versão']['item_size']=63;data['active']='Minha versão';settings.write_presets(data)
  self.assertEqual(settings.read_presets()['presets']['Minha versão']['item_size'],63)
 def test_images_are_copied_for_user_presets(self):
  values=settings.builtin_presets()['Steeve'];saved=settings.save(values)
  for key in ('image','cancel_icon','items_icon','items_open_icon'):
   self.assertEqual(Path(saved[key]).parent,settings.CONFIG.parent/'assets')
   self.assertEqual(Path(saved[key]).read_bytes(),Path(values[key]).read_bytes())
 def test_separate_open_icon_does_not_rotate(self):
  p=settings.builtin_presets()['Steeve']
  self.assertEqual(settings.items_icon_state(p,True),(p['items_open_icon'],False))
 def test_only_file_size_changes_file_icon_size(self):
  values=copy.deepcopy(settings.DEFAULTS);size=settings.item_layout(values,'file',0)[2]
  for key in ('chaos','spread','overlap','cart_size','cancel_size','items_size'):
   updated=copy.deepcopy(values);updated[key]+=10
   self.assertEqual(settings.item_layout(updated,'file',0)[2],size)

if __name__=='__main__':unittest.main()
