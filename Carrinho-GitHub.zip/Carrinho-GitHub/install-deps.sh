#!/bin/sh
set -eu
if ! command -v apt-get >/dev/null 2>&1; then
 echo 'Este instalador de dependências atende Linux Mint e Ubuntu/Debian com Cinnamon.'
 echo 'Consulte o README para a lista completa de pacotes.'; exit 1
fi
sudo apt-get update
sudo apt-get install -y python3 python3-gi python3-gi-cairo python3-cairo python3-xlib gir1.2-gtk-3.0 libglib2.0-bin systemd dbus-user-session
