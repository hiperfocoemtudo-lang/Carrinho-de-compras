#!/bin/sh
set -eu
if [ "$(id -u)" -eq 0 ]; then echo 'Execute como seu usuário, sem sudo.'; exit 1; fi
case "${1:-}" in ''|--purge) ;; *) echo 'Uso: ./uninstall.sh [--purge]'; exit 1;; esac
/usr/bin/python3 - "${1:-}" <<'PY'
import subprocess,shutil,sys
from pathlib import Path
from gi.repository import Gio
home=Path.home();root=home/'.local/share/carrinho-y2k'
launcher=root/'Abrir-Carrinho.sh'
if launcher.exists():
 try:subprocess.run([str(launcher),'--quit'],timeout=8,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 except subprocess.TimeoutExpired:pass
subprocess.run(['systemctl','--user','disable','--now','carrinho-gestos.service'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
settings=Gio.Settings.new('org.cinnamon.desktop.keybindings')
settings.set_strv('custom-list',[k for k in settings.get_strv('custom-list') if k!='carrinho-y2k'])
custom=Gio.Settings.new_with_path('org.cinnamon.desktop.keybindings.custom-keybinding','/org/cinnamon/desktop/keybindings/custom-keybindings/carrinho-y2k/')
for key in ('name','command','binding'):custom.reset(key)
Gio.Settings.sync()
for path in (home/'.config/systemd/user/carrinho-gestos.service',home/'.config/autostart/carrinho-y2k.desktop',home/'.local/share/applications/carrinho-y2k.desktop'):path.unlink(missing_ok=True)
if root.exists():shutil.rmtree(root)
if sys.argv[1]=='--purge':
 for path in (home/'.config/carrinho-y2k',home/'.local/state/carrinho-y2k'):
  if path.exists():shutil.rmtree(path)
subprocess.run(['systemctl','--user','daemon-reload'],check=True)
print('Carrinho removido. Os arquivos originais da cesta não foram alterados.')
print('Preferências preservadas.' if sys.argv[1]!='--purge' else 'Preferências e referências também removidas.')
PY
