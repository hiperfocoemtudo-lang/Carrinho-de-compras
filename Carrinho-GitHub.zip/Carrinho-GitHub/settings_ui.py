import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk,Gdk,GdkPixbuf,GLib
import cairo,json,copy,math,hashlib,shutil,uuid,time
from pathlib import Path
CONFIG=Path.home()/'.config/carrinho-y2k/settings.json'
DEFAULTS={'image':'','cancel_icon':'','items_icon':'','items_open_icon':'','items_open_mode':'invert','position':[.40,.34],'chaos':65,'spread':50,'overlap':55,'item_size':34,'cart_size':150,'cancel_size':34,'items_size':34,'cancel_position':[.807,.16],'items_position':[.873,.613],'animation':'slide','duration':1.65}
def load():
 d=copy.deepcopy(DEFAULTS)
 try:
  raw=json.loads(CONFIG.read_text())
  for k in d:
   if k in raw:d[k]=raw[k]
  for k in ('chaos','spread','overlap'):d[k]=max(0,min(100,float(d[k])))
  d['item_size']=max(12,min(80,float(d['item_size'])));d['cart_size']=max(100,min(300,float(d['cart_size'])))
  for k in ('cancel_size','items_size'):d[k]=max(14,min(80,float(d[k])))
  for k in ('cancel_position','items_position'):
   d[k]=[max(0,min(1,float(v))) for v in d[k][:2]]
   if len(d[k])!=2:raise ValueError()
  if d['items_open_mode'] not in ('invert','image'):d['items_open_mode']='invert'
  d['duration']=max(.2,min(4,float(d['duration'])))
  d['position']=[max(0,min(1,float(v))) for v in d['position'][:2]]
  if len(d['position'])!=2:raise ValueError()
 except (OSError,ValueError,TypeError):
  try:d=copy.deepcopy(builtin_presets()['Steeve'])
  except (OSError,ValueError,KeyError):d=copy.deepcopy(DEFAULTS)
 return d
def save(d):
 CONFIG.parent.mkdir(parents=True,exist_ok=True)
 d=copy.deepcopy(d)
 for k in ('image','cancel_icon','items_icon','items_open_icon'):
  if d[k]:
   src=Path(d[k]);GdkPixbuf.Pixbuf.new_from_file(str(src))
   assets=CONFIG.parent/'assets';assets.mkdir(exist_ok=True)
   if src.parent!=assets:
    target=assets/(uuid.uuid4().hex+src.suffix);shutil.copy2(src,target);d[k]=str(target)
 temp=CONFIG.with_suffix('.tmp');temp.write_text(json.dumps(d,ensure_ascii=False,indent=2));temp.replace(CONFIG)
 return d
def preset_file():return CONFIG.with_name('presets.json')
def write_presets(data):
 path=preset_file();path.parent.mkdir(parents=True,exist_ok=True)
 temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,ensure_ascii=False,indent=2));temp.replace(path)
def builtin_presets():
 root=Path(__file__).resolve().parent
 raw=json.loads((root/'presets.json').read_text())
 values=copy.deepcopy(raw['presets'])
 for name,d in values.items():
  values[name]={**copy.deepcopy(DEFAULTS),**d}
  for key in ('image','cancel_icon','items_icon','items_open_icon'):
   value=values[name].get(key,'')
   if value.startswith('@'):
    asset=(root/value[1:]).resolve()
    if root not in asset.parents or not asset.is_file():raise ValueError('Imagem incorporada indisponível: '+value)
    values[name][key]=str(asset)
 return values

def read_presets(current=None):
 builtin=builtin_presets()
 try:
  data=json.loads(preset_file().read_text())
  if not isinstance(data.get('presets'),dict) or not data['presets']:raise ValueError()
 except (OSError,ValueError,TypeError):
  data={'active':'Steeve','presets':copy.deepcopy(builtin)}
  write_presets(data)
 missing=False
 for name,values in builtin.items():
  if name not in data['presets']:data['presets'][name]=copy.deepcopy(values);missing=True
 for name,values in data['presets'].items():data['presets'][name]={**copy.deepcopy(DEFAULTS),**values}
 if data.get('active') not in data['presets']:data['active']=next(iter(data['presets']));missing=True
 if missing:write_presets(data)
 return data
def items_icon_state(d,expanded):
 if expanded and d.get('items_open_mode')=='image' and d.get('items_open_icon'):
  return d['items_open_icon'],False
 return d['items_icon'],bool(expanded)
def item_layout(d,key,index):
 h=hashlib.sha256(str(key).encode()).digest();size=float(d['cart_size']);icon=float(d['item_size'])
 spread=(.025+.004*float(d['spread']))*(1-.007*float(d['overlap']))*size
 chaos=float(d['chaos'])/100
 return (d['position'][0]*size-icon/2+(h[0]/255-.5)*spread*2,
         d['position'][1]*size-icon/2+(h[1]/255-.5)*spread*1.3,
         icon,(h[3]/255-.5)*1.2*chaos)
STYLE=b'''
.settings { background: #f3f5f9; color: #202a3b; font-family: Sans; }
.settings label { color: #273348; }
.settings .sidebar { background: #e9edf5; border-radius: 16px; padding: 20px; }
.settings .card { background: #ffffff; border: 1px solid #e0e5ee; border-radius: 16px; padding: 18px; }
.settings .title { font-size: 23px; font-weight: bold; }
.settings .muted { color: #6c788a; font-size: 12px; }
.settings button { background-image:none; background:#fff; color:#25334a; border:1px solid #d6deeb; border-radius:10px; padding:9px 14px; }
.settings button:hover { background:#edf4ff; border-color:#8ab6f5; }
.settings button.primary label { color: #ffffff; }
.settings button.primary:disabled { background:#dce1e8; border-color:#d2d8e0; }
.settings button.primary:disabled label { color:#6a7482; }
.settings button.primary { background:#1968d5; color:#fff; border-color:#1968d5; }
.settings .slider-row { background:#ffffff; border:1px solid #e1e7ef; border-radius:12px; padding:10px; }
.settings scale trough { background:#e6ecf5; min-height:5px; border-radius:5px; }
.settings scale highlight { background:#2876e2; }
.settings combobox button { padding:6px; }
'''
class SettingsWindow(Gtk.ApplicationWindow):
 def __init__(self,app,values,default_image,apply):
  super().__init__(application=app,title='Carrinho • Configurações')
  self.set_resizable(True)
  self.set_type_hint(Gdk.WindowTypeHint.NORMAL)
  self.set_decorated(True)
  area=Gdk.Display.get_default().get_monitor(0).get_workarea()
  self.set_default_size(min(1030,area.width-70),min(710,area.height-90));self.set_size_request(760,440)
  self.get_style_context().add_class('settings');self.draft=copy.deepcopy(values);self.default_image=str(default_image);self.apply_callback=apply;self.placing=False;self.play_start=None;self.cache={};self.widgets={};self.image_buttons={};self.syncing=False;self.saved_values=copy.deepcopy(values);self.presets=read_presets(values)
  provider=Gtk.CssProvider();provider.load_from_data(STYLE);Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(),provider,Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION+1)
  root_scroll=Gtk.ScrolledWindow();root_scroll.set_policy(Gtk.PolicyType.AUTOMATIC,Gtk.PolicyType.AUTOMATIC);self.add(root_scroll)
  outer=Gtk.Box(spacing=22);outer.set_border_width(22);root_scroll.add(outer)
  side=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=16);side.get_style_context().add_class('sidebar');side.set_size_request(170,-1);outer.pack_start(side,False,False,0)
  self.text(side,'Carrinho','title');self.text(side,'PERSONALIZAÇÃO','muted')
  for t in ('◈  Aparência','▦  Disposição dos itens','✦  Animação de entrada'):self.text(side,t)
  self.text(side,'PRÉ-DEFINIÇÕES','muted')
  self.preset_combo=Gtk.ComboBoxText()
  for name in self.presets['presets']:self.preset_combo.append(name,name)
  self.preset_combo.set_active_id(self.presets['active']);self.preset_combo.connect('changed',self.select_preset);side.pack_start(self.preset_combo,False,False,0)
  new_preset=Gtk.Button(label='Salvar nova pré-definição');new_preset.connect('clicked',self.new_preset);side.pack_start(new_preset,False,False,0)
  reset=Gtk.Button(label='Restaurar padrões');reset.connect('clicked',self.reset);side.pack_end(reset,False,False,0)
  main=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=14);outer.pack_start(main,True,True,0)
  self.text(main,'Deixe o carrinho do seu jeito','title');self.text(main,'Imagens, posição dos arquivos e movimento em uma prévia ao vivo.','muted')
  split=Gtk.Paned(orientation=Gtk.Orientation.HORIZONTAL);main.pack_start(split,True,True,0)
  scroll=Gtk.ScrolledWindow();scroll.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC);split.pack1(scroll,True,False)
  controls=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12);controls.set_margin_end(16);scroll.add(controls)
  for key,label in [('image','Imagem do carrinho'),('cancel_icon','Ícone de cancelar'),('items_icon','Ícone de ver itens')]:
   button=Gtk.Button(label='Escolher '+label.lower()+'…');button.connect('clicked',self.choose,key);controls.pack_start(button,False,False,0);self.image_buttons[key]=(button,label)
  self.text(controls,'Ícone quando os itens estão abertos')
  mode=Gtk.ComboBoxText();mode.append('invert','Inverter a imagem da seta');mode.append('image','Usar outra imagem para recolher')
  mode.set_active_id(self.draft['items_open_mode']);mode.connect('changed',self.open_mode_changed);controls.pack_start(mode,False,False,0);self.widgets['items_open_mode']=mode
  self.open_icon_button=Gtk.Button(label='Escolher imagem para recolher…');self.open_icon_button.connect('clicked',self.choose,'items_open_icon');self.open_icon_button.set_sensitive(self.draft['items_open_mode']=='image');controls.pack_start(self.open_icon_button,False,False,0);self.image_buttons['items_open_icon']=(self.open_icon_button,'Imagem para recolher')
  for key,label,lo,hi,step in [('cart_size','Tamanho da imagem do carrinho (px)',100,300,1),('cancel_size','Tamanho do ícone de cancelar',14,80,1),('items_size','Tamanho do ícone de ver itens',14,80,1),('item_size','Tamanho dos ícones de arquivos (px)',12,80,1),('chaos','Inclinação aleatória dos arquivos',0,100,1),('spread','Espalhamento',0,100,1),('overlap','Sobreposição',0,100,1)]:
   group=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=3);group.get_style_context().add_class('slider-row');controls.pack_start(group,False,False,0)
   self.text(group,label);w=Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL,lo,hi,step);w.set_value(self.draft[key]);w.set_digits(0);w.connect('value-changed',self.changed,key);group.pack_start(w,False,False,0);self.widgets[key]=w
   if key in {'spread': 'Maior valor distribui os arquivos em uma área mais ampla.', 'overlap': 'Maior valor aproxima os centros dos arquivos, aumentando a sobreposição.', 'chaos': 'Maior valor inclina os arquivos em ângulos mais variados.'}:w.set_tooltip_text({'spread': 'Maior valor distribui os arquivos em uma área mais ampla.', 'overlap': 'Maior valor aproxima os centros dos arquivos, aumentando a sobreposição.', 'chaos': 'Maior valor inclina os arquivos em ângulos mais variados.'}[key])
  self.text(controls,'Animação ao aparecer')
  combo=Gtk.ComboBoxText()
  for key,label in [('slide','Deslizar da lateral'),('fade','Esmaecer'),('zoom','Aproximar suavemente'),('rise','Surgir de baixo'),('none','Sem animação')]:combo.append(key,label)
  combo.set_active_id(self.draft['animation']);combo.connect('changed',lambda w:self.set_value('animation',w.get_active_id()));controls.pack_start(combo,False,False,0);self.widgets['animation']=combo
  self.text(controls,'Duração (segundos)');duration=Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL,.2,4,.05);duration.set_digits(2);duration.set_value(self.draft['duration']);duration.connect('value-changed',self.changed,'duration');controls.pack_start(duration,False,False,0);self.widgets['duration']=duration
  preview=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=10);preview.get_style_context().add_class('card');preview.set_size_request(305,-1);split.pack2(preview,True,False)
  self.text(preview,'PRÉVIA AO VIVO','muted');self.preview=Gtk.DrawingArea();self.preview.set_size_request(240,180);self.preview.add_events(Gdk.EventMask.BUTTON_PRESS_MASK);self.preview.connect('draw',self.draw);self.preview.connect('button-press-event',self.place);preview.pack_start(self.preview,True,True,0)
  self.preview_open=Gtk.CheckButton(label='Prévia: ícone do estado aberto');self.preview_open.connect('toggled',lambda w:self.preview.queue_draw());preview.pack_start(self.preview_open,False,False,0)
  self.position_target=Gtk.ComboBoxText()
  for key,label in [('position','Itens dentro do carrinho'),('cancel_position','Ícone de cancelar'),('items_position','Ícone de ver itens')]:self.position_target.append(key,label)
  self.position_target.set_active_id('position');preview.pack_start(self.position_target,False,False,0)
  self.position_button=Gtk.ToggleButton(label='Posicionar elemento');self.position_button.connect('toggled',lambda b:setattr(self,'placing',b.get_active()));preview.pack_start(self.position_button,False,False,0)
  play=Gtk.Button(label='▶ Testar animação');play.connect('clicked',self.play);preview.pack_start(play,False,False,0)
  self.hint=self.text(preview,'Escolha o elemento, ative Posicionar e clique no local desejado da imagem.','muted');self.hint.set_line_wrap(True)
  row=Gtk.Box(spacing=10);main.pack_end(row,False,False,0)
  launch=Gtk.Button(label='Mostrar carrinho');launch.connect('clicked',lambda *a:app.activate_cart('show'));row.pack_start(launch,False,False,0)
  self.save_button=Gtk.Button(label='Salvar alterações');apply=self.save_button;apply.get_style_context().add_class('primary');apply.connect('clicked',self.commit);row.pack_end(apply,False,False,0)
  self.notice=self.text(main,'As alterações são aplicadas ao salvar.','muted')
  self.connect('delete-event',lambda *a:self.hide() or True);self.update_dirty();self.show_all()
 def text(self,box,text,style=None):
  label=Gtk.Label(label=text,xalign=0)
  if style:label.get_style_context().add_class(style)
  box.pack_start(label,False,False,0);return label
 def set_value(self,key,value):
  if self.syncing:return
  self.draft[key]=value;self.preview.queue_draw();self.update_dirty()
 def changed(self,w,key):self.set_value(key,w.get_value())
 def open_mode_changed(self,widget):
  self.set_value('items_open_mode',widget.get_active_id())
  if hasattr(self,'open_icon_button'):self.open_icon_button.set_sensitive(widget.get_active_id()=='image')
 def choose(self,button,key):
  dialog=Gtk.FileChooserDialog(title='Escolher imagem',transient_for=self,action=Gtk.FileChooserAction.OPEN);dialog.add_buttons('Cancelar',Gtk.ResponseType.CANCEL,'Usar imagem',Gtk.ResponseType.OK)
  filt=Gtk.FileFilter();filt.set_name('Imagens');filt.add_pixbuf_formats();dialog.add_filter(filt)
  if dialog.run()==Gtk.ResponseType.OK:
   path=dialog.get_filename()
   try:GdkPixbuf.Pixbuf.new_from_file(path);self.set_value(key,path);button.set_label(Path(path).name)
   except Exception as exc:self.notice.set_text('Não foi possível abrir esta imagem: '+str(exc))
  dialog.destroy()
 def pix(self,path):
  if path not in self.cache:self.cache[path]=GdkPixbuf.Pixbuf.new_from_file(path)
  return self.cache[path]
 def image(self,cr,path,x,y,w,h):
  try:
   p=self.pix(path);scale=min(w/p.get_width(),h/p.get_height());cr.save();cr.translate(x+(w-p.get_width()*scale)/2,y+(h-p.get_height()*scale)/2);cr.scale(scale,scale);Gdk.cairo_set_source_pixbuf(cr,p,0,0);cr.paint();cr.restore()
  except Exception:pass
 def play(self,*args):
  self.play_start=time.monotonic()
  def frame():
   if self.play_start is None:return False
   self.preview.queue_draw()
   if time.monotonic()-self.play_start>self.draft['duration']:
    self.play_start=None;return False
   return True
  GLib.timeout_add(16,frame)
 def draw(self,widget,cr):
  a=widget.get_allocation();zoom=min((a.width-24)/300,(a.height-30)/300,1.);size=self.draft['cart_size']*zoom;x=(a.width-size)/2;y=(a.height-size)/2;self.bounds=(x,y,size)
  cr.set_source_rgb(.97,.98,1);cr.paint()
  cr.save();cr.push_group();opacity=1
  if self.play_start is not None:
   t=min(1,(time.monotonic()-self.play_start)/self.draft['duration']);rest=(1-t)**3;mode=self.draft['animation']
   if mode=='slide':cr.translate((a.width+size)*rest,0)
   if mode=='fade':opacity=t
   if mode=='rise':cr.translate(0,size*.6*rest)
   if mode=='zoom':
    factor=1-.35*rest;cr.translate(x+size/2,y+size/2);cr.scale(factor,factor);cr.translate(-x-size/2,-y-size/2)
  cr.save()
  if not self.draft['image']:
   cr.rectangle(0,0,a.width,a.height)
   for rx,ry,rw,rh in [(710,40,240,240),(787,510,213,235)]:cr.rectangle(x+rx*size/1024,y+ry*size/1024,rw*size/1024,rh*size/1024)
   cr.set_fill_rule(cairo.FILL_RULE_EVEN_ODD);cr.clip()
  self.image(cr,self.draft['image'] or self.default_image,x,y,size,size)
  cr.restore()
  cr.save();cr.translate(x,y);cr.scale(size/self.draft['cart_size'],size/self.draft['cart_size'])
  for i in range(7):
   ix,iy,sz,angle=item_layout(self.draft,'preview-'+str(i),i);cr.save();cr.translate(ix+sz/2,iy+sz/2);cr.rotate(angle);cr.set_source_rgba(.04,.12,.25,.18);cr.rectangle(-sz/2+2,-sz/2+3,sz,sz);cr.fill();cr.set_source_rgb(1,1,1);cr.rectangle(-sz/2,-sz/2,sz,sz);cr.fill();cr.set_source_rgb(.16,.45,.88);cr.rectangle(-sz/2+5,-sz/2+5,max(3,sz-10),sz*.33);cr.fill();cr.restore()
  cr.restore()
  for key,pkey,skey,crop in [('cancel_icon','cancel_position','cancel_size',(710,40,240,240)),('items_icon','items_position','items_size',(787,510,213,235))]:
   px,py=self.draft[pkey];icon_size=self.draft[skey]*size/self.draft['cart_size']
   path=self.draft[key];rotate=False
   if key=='items_icon':path,rotate=items_icon_state(self.draft,self.preview_open.get_active())
   try:
    pix=self.pix(path) if path else self.pix(self.default_image).new_subpixbuf(*crop)
    cr.save();cr.translate(x+px*size,y+py*size)
    if rotate:cr.rotate(math.pi)
    factor=icon_size/max(pix.get_width(),pix.get_height());cr.scale(factor,factor);Gdk.cairo_set_source_pixbuf(cr,pix,-pix.get_width()/2,-pix.get_height()/2);cr.paint();cr.restore()
   except Exception:pass
  px=x+self.draft['position'][0]*size;py=y+self.draft['position'][1]*size;cr.set_source_rgba(.1,.45,.9,.9);cr.set_line_width(1.5);cr.arc(px,py,6,0,math.tau);cr.stroke();cr.move_to(px-10,py);cr.line_to(px+10,py);cr.move_to(px,py-10);cr.line_to(px,py+10);cr.stroke();cr.pop_group_to_source();cr.paint_with_alpha(opacity);cr.restore();return False
 def place(self,widget,event):
  if not self.placing:return False
  x,y,size=self.bounds
  if x<=event.x<=x+size and y<=event.y<=y+size:
   self.draft[self.position_target.get_active_id()]=[(event.x-x)/size,(event.y-y)/size];self.preview.queue_draw();self.position_button.set_active(False);self.hint.set_text('Posição definida. Salve para aplicar ao carrinho.');self.update_dirty()
  return True
 def update_dirty(self):
  if not hasattr(self,'save_button'):return
  dirty=self.draft!=self.saved_values
  self.save_button.set_sensitive(dirty)
  self.save_button.set_label('Salvar alterações' if dirty else 'Salvo')
 def sync_controls(self):
  self.syncing=True
  try:
   for k,w in self.widgets.items():
    if isinstance(w,Gtk.ComboBoxText):w.set_active_id(self.draft[k])
    else:w.set_value(self.draft[k])
   for key,(button,label) in self.image_buttons.items():button.set_label(Path(self.draft[key]).name if self.draft[key] else 'Escolher '+label.lower()+'…')
   self.open_icon_button.set_sensitive(self.draft['items_open_mode']=='image')
  finally:self.syncing=False
  self.cache.clear();self.play_start=None;self.preview.queue_draw();self.update_dirty()
 def commit(self,*args):
  if self.draft['items_open_mode']=='image' and not self.draft['items_open_icon']:
   self.notice.set_text('Escolha a imagem para recolher os itens antes de salvar.');return False
  try:
   values=save(self.draft)
   self.presets['presets'][self.presets['active']]=copy.deepcopy(values);write_presets(self.presets)
   self.draft=values;self.saved_values=copy.deepcopy(values);self.apply_callback(values)
   self.notice.set_text('Configurações e pré-definição salvas.');self.sync_controls();return True
  except Exception as exc:self.notice.set_text('Não foi possível salvar: '+str(exc));return False
 def select_preset(self,combo):
  if self.syncing:return
  name=combo.get_active_id()
  if not name or name==self.presets['active']:return
  if self.draft!=self.saved_values:
   dialog=Gtk.MessageDialog(transient_for=self,modal=True,message_type=Gtk.MessageType.QUESTION,buttons=Gtk.ButtonsType.OK_CANCEL,text='Trocar sem salvar as alterações?');dialog.format_secondary_text('As alterações pendentes serão descartadas. A pré-definição salva será mantida.');answer=dialog.run();dialog.destroy()
   if answer!=Gtk.ResponseType.OK:
    self.syncing=True;combo.set_active_id(self.presets['active']);self.syncing=False;return
  try:
   values=save(copy.deepcopy(self.presets['presets'][name]))
   self.presets['active']=name;write_presets(self.presets)
   self.draft=values;self.saved_values=copy.deepcopy(values);self.apply_callback(values);self.sync_controls()
   self.notice.set_text('Pré-definição aplicada: '+name)
  except Exception as exc:self.notice.set_text('Não foi possível aplicar: '+str(exc))
 def save_named_preset(self,name):
  name=name.strip()
  if not name or len(name)>64:raise ValueError('Escolha um nome com 1 a 64 caracteres.')
  if name in self.presets['presets']:raise ValueError('Esse nome já existe. Escolha outro nome.')
  if self.draft['items_open_mode']=='image' and not self.draft['items_open_icon']:raise ValueError('Escolha a imagem de recolher antes de salvar.')
  values=save(self.draft)
  self.presets['presets'][name]=copy.deepcopy(values);self.presets['active']=name;write_presets(self.presets)
  self.draft=values;self.saved_values=copy.deepcopy(values);self.apply_callback(values)
  self.syncing=True;self.preset_combo.append(name,name);self.preset_combo.set_active_id(name);self.syncing=False
  self.sync_controls();self.notice.set_text('Pré-definição salva: '+name)
 def new_preset(self,*args):
  dialog=Gtk.Dialog(title='Salvar nova pré-definição',transient_for=self,modal=True);dialog.add_buttons('Cancelar',Gtk.ResponseType.CANCEL,'Salvar',Gtk.ResponseType.OK)
  entry=Gtk.Entry();entry.set_placeholder_text('Nome da pré-definição');entry.set_max_length(64);entry.set_activates_default(True);dialog.set_default_response(Gtk.ResponseType.OK)
  box=dialog.get_content_area();box.set_border_width(20);box.set_spacing(10);box.add(Gtk.Label(label='Salvar todas as configurações atuais com o nome:'));box.add(entry);dialog.show_all()
  while dialog.run()==Gtk.ResponseType.OK:
   try:self.save_named_preset(entry.get_text());break
   except Exception as exc:self.notice.set_text(str(exc));entry.set_tooltip_text(str(exc))
  dialog.destroy()
 def reset(self,*args):
  d=Gtk.MessageDialog(transient_for=self,modal=True,message_type=Gtk.MessageType.QUESTION,buttons=Gtk.ButtonsType.OK_CANCEL,text='Restaurar configurações originais?');d.format_secondary_text('Imagens, posição, disposição e animação voltarão ao padrão. Os arquivos da cesta serão mantidos.');answer=d.run();d.destroy()
  if answer!=Gtk.ResponseType.OK:return
  self.draft=copy.deepcopy(DEFAULTS)
  self.sync_controls()
  self.commit()
