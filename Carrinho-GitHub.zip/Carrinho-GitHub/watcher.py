#!/usr/bin/python3
"""File-drag shake integration for Cinnamon/X11. Never reads dragged contents."""
import os
import time
import fcntl
import subprocess
from pathlib import Path
from collections import deque
from Xlib import X, display, error

ALLOWED=('nemo','nautilus','thunar','caja','pcmanfm','file-roller','file_roller','fileroller','engrampa','xarchiver','ark','peazip')
FILE_TYPES={'text/uri-list','x-special/gnome-icon-list','application/x-gnome-icon-list'}

class Shake:
    def __init__(self):self.points=deque()
    def reset(self):self.points.clear()
    def feed(self,t,x,y):
        self.points.append((t,x,y))
        while self.points and t-self.points[0][0]>.88:self.points.popleft()
        if len(self.points)<9:return False
        xs=[p[1] for p in self.points];ys=[p[2] for p in self.points]
        if max(xs)-min(xs)<78 or max(ys)-min(ys)>115:return False
        direction=0;turns=0;travel=0;anchor=xs[0]
        for current in xs[1:]:
            delta=current-anchor
            if abs(delta)<19:continue
            sign=1 if delta>0 else -1
            if direction and direction!=sign:turns+=1
            direction=sign;travel+=abs(delta);anchor=current
        return turns>=3 and travel>=250

class Watcher:
    def __init__(self,on_shake=None):
        self.on_shake=on_shake
        self.d=display.Display();self.d.set_error_handler(lambda *args:None)
        self.root=self.d.screen().root
        self.atoms={name:self.d.intern_atom(name) for name in ('XdndSelection','XdndTypeList','TARGETS','CARRINHO_TARGETS','_NET_ACTIVE_WINDOW','_NET_WM_PID','WM_CLIENT_LEADER')}
        self.receiver=self.root.create_window(-1,-1,1,1,0,X.CopyFromParent,X.InputOnly,X.CopyFromParent,event_mask=X.PropertyChangeMask)
        self.source=0;self.allowed=False;self.typed=False;self.triggered=False;self.shake=Shake();self.started=0

    def property(self,window,name):
        try:return window.get_full_property(self.atoms[name],X.AnyPropertyType)
        except error.XError:return None

    def identity(self,window):
        """Prefer the drag owner/client leader; use active window only if anonymous."""
        seen=set();queue=[window]
        while queue and len(seen)<8:
            win=queue.pop(0)
            if not win or win.id in seen or win.id==self.root.id:continue
            seen.add(win.id)
            try:
                cls=win.get_wm_class()
                if cls:return ' '.join(cls).lower()
                pid=self.property(win,'_NET_WM_PID')
                if pid and len(pid.value):
                    try:return Path(f'/proc/{pid.value[0]}/comm').read_text().strip().lower()
                    except OSError:pass
                leader=self.property(win,'WM_CLIENT_LEADER')
                if leader and len(leader.value):queue.append(self.d.create_resource_object('window',int(leader.value[0])))
                queue.append(win.query_tree().parent)
            except error.XError:pass
        return ''

    def inspect(self,owner):
        identity=self.identity(owner)
        if not identity:
            active=self.property(self.root,'_NET_ACTIVE_WINDOW')
            if active and len(active.value):identity=self.identity(self.d.create_resource_object('window',int(active.value[0])))
        self.allowed=any(name in identity for name in ALLOWED)
        self.typed=False
        if not self.allowed:return
        types=self.property(owner,'XdndTypeList')
        if types:
            names={self.d.get_atom_name(int(atom)) for atom in types.value}
            self.typed=bool(FILE_TYPES&names)
        if not self.typed:
            self.receiver.convert_selection(self.atoms['XdndSelection'],self.atoms['TARGETS'],self.atoms['CARRINHO_TARGETS'],X.CurrentTime)
            self.d.flush()
        print(f'Arraste identificado: {identity}; arquivos={self.typed}',flush=True)

    def events(self):
        while self.d.pending_events():
            event=self.d.next_event()
            if event.type==X.SelectionNotify and event.property==self.atoms['CARRINHO_TARGETS']:
                prop=self.property(self.receiver,'CARRINHO_TARGETS')
                if prop and self.d.get_selection_owner(self.atoms['XdndSelection']).id==self.source:
                    names={self.d.get_atom_name(int(atom)) for atom in prop.value}
                    self.typed=bool(FILE_TYPES&names)
                self.receiver.delete_property(self.atoms['CARRINHO_TARGETS'])

    def poll(self):
        self.events()
        pointer=self.root.query_pointer()
        if not pointer.mask&X.Button1Mask:
            self.source=0;self.shake.reset();self.triggered=False;return
        owner=self.d.get_selection_owner(self.atoms['XdndSelection'])
        if not owner or not owner.id:
            self.source=0;self.shake.reset();return
        if owner.id!=self.source:
            self.source=owner.id;self.shake.reset();self.triggered=False;self.inspect(owner)
        if not self.allowed or not self.typed or self.triggered:return
        if self.shake.feed(time.monotonic(),pointer.root_x,pointer.root_y):
            self.triggered=True
            launcher=Path(__file__).resolve().parent/'Abrir-Carrinho.sh'
            if self.on_shake:self.on_shake()
            else:subprocess.Popen([str(launcher),'--show'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
            print('Sacudida durante arraste de arquivos: carrinho aberto.',flush=True)

def main():
    state=Path(os.environ.get('XDG_RUNTIME_DIR','/tmp'))/'carrinho-gestos.lock'
    lock=state.open('w')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:return
    watcher=Watcher()
    while True:
        try:watcher.poll()
        except (error.XError,OSError) as exc:
            print(f'Evento ignorado: {exc}',flush=True);watcher.source=0;watcher.shake.reset()
        time.sleep(.025)

if __name__=='__main__':main()
