# Imagens incorporadas

`cart.png` é a arte de colagem padrão fornecida para este aplicativo.
`presets/steeve/` contém as quatro imagens fornecidas para a pré-definição Steeve.

Esses arquivos são incluídos para que as duas pré-definições funcionem sem arquivos externos. A licença MIT do código não se estende automaticamente a essas imagens. Não é atribuída aqui uma licença adicional de redistribuição das artes.
