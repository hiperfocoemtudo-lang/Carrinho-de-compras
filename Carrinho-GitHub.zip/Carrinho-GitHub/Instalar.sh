#!/bin/sh
set -eu
if [ "$(id -u)" -eq 0 ]; then echo 'Execute como seu usuário, sem sudo.'; exit 1; fi
if [ "${XDG_SESSION_TYPE:-x11}" != x11 ]; then echo 'Entre em uma sessão Cinnamon no X11 para instalar.'; exit 1; fi
SOURCE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
DEST="$HOME/.local/share/carrinho-y2k"
/usr/bin/python3 -c 'import gi, cairo, Xlib; gi.require_version("Gtk", "3.0")' || {
    echo 'Instale: sudo apt install python3-gi python3-gi-cairo python3-cairo python3-xlib gir1.2-gtk-3.0'; exit 1;
}
/usr/bin/python3 - "$SOURCE" "$DEST" <<'PY'
import sys,os,signal,shutil,subprocess,time
from pathlib import Path
from gi.repository import Gio
source,root=map(Path,sys.argv[1:])
if not (source/'presets.json').is_file():raise SystemExit('Pacote incompleto: presets.json não encontrado.')
required='org.cinnamon.desktop.keybindings'
if required not in Gio.Settings.list_schemas():raise SystemExit('Esta integração requer o desktop Cinnamon.')
subprocess.run(['systemctl','--user','show-environment'],check=True,stdout=subprocess.DEVNULL)
subprocess.run(['systemctl','--user','stop','carrinho-gestos.service'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
# Stop only this installed app; leave its saved file references intact.
for proc in Path('/proc').glob('[0-9]*'):
 try:
  args=(proc/'cmdline').read_bytes().split(b'\0')
  if len(args)>1 and b'python' in args[0] and (args[1]==str(root/'carrinho.py').encode() or (args[1]==b'carrinho.py' and (proc/'cwd').resolve()==root)):
   os.kill(int(proc.name),signal.SIGTERM)
 except (OSError,PermissionError):pass
(root/'assets').mkdir(parents=True,exist_ok=True)
for name in ('carrinho.py','settings_ui.py','watcher.py','Abrir-Carrinho.sh','Iniciar-integracao.sh'):
 shutil.copy2(source/name,root/name)
shutil.copytree(source/'assets',root/'assets',dirs_exist_ok=True)
shutil.copy2(source/'presets.json',root/'presets.json')
sys.path.insert(0,str(root))
from settings_ui import read_presets, load as load_settings
read_presets(load_settings())
for name in ('Abrir-Carrinho.sh','Iniciar-integracao.sh'):(root/name).chmod(0o755)
def quote(s):return '"'+str(s).replace('\\','\\\\').replace('"','\\"').replace('`','\\`').replace('$','\\$')+'"'
entry=f'''[Desktop Entry]
Type=Application
Name=Carrinho
Comment=Junte arquivos • Ctrl + Super + C • Sacuda durante um arraste para abrir
Exec={quote(root/'Abrir-Carrinho.sh')} --settings
Icon={root}/assets/cart.png
Terminal=false
Categories=Utility;FileTools;
'''
launcher=Path.home()/'.local/share/applications/carrinho-y2k.desktop'
launcher.parent.mkdir(parents=True,exist_ok=True);launcher.write_text(entry)
autostart=Path.home()/'.config/autostart/carrinho-y2k.desktop'
autostart.parent.mkdir(parents=True,exist_ok=True)
autostart.write_text(f'''[Desktop Entry]
Type=Application
Name=Integração Carrinho Pixel
Exec={quote(root/'Iniciar-integracao.sh')}
Terminal=false
X-GNOME-Autostart-enabled=true
X-GNOME-Autostart-Delay=3
''')
unit=Path.home()/'.config/systemd/user/carrinho-gestos.service'
unit.parent.mkdir(parents=True,exist_ok=True)
unit.write_text(f'''[Unit]
Description=Sacudida de arquivos para abrir o Carrinho Pixel
StartLimitIntervalSec=0

[Service]
Type=simple
ExecStart=/usr/bin/python3 {quote(root/'watcher.py')}
Restart=always
RestartSec=3

[Install]
WantedBy=default.target
''')
settings=Gio.Settings.new('org.cinnamon.desktop.keybindings')
key='carrinho-y2k'
custom=Gio.Settings.new_with_path('org.cinnamon.desktop.keybindings.custom-keybinding',f'/org/cinnamon/desktop/keybindings/custom-keybindings/{key}/')
custom.set_string('name','Carrinho');custom.set_string('command',quote(root/'Abrir-Carrinho.sh')+' --toggle')
custom.set_strv('binding',['<Control><Super>c'])
entries=list(settings.get_strv('custom-list'))
if key not in entries:entries.append(key)
settings.set_strv('custom-list',entries);Gio.Settings.sync()
subprocess.run(['systemctl','--user','daemon-reload'],check=True)
subprocess.run(['systemctl','--user','import-environment']+[key for key in ('DISPLAY','XAUTHORITY','DBUS_SESSION_BUS_ADDRESS','XDG_CURRENT_DESKTOP') if key in os.environ],check=True)
subprocess.run(['systemctl','--user','enable','--now','carrinho-gestos.service'],check=True)
log=Path.home()/'.local/state/carrinho-y2k/app.log'
log.parent.mkdir(parents=True,exist_ok=True)
with log.open('a') as out:subprocess.Popen([str(root/'Abrir-Carrinho.sh'),'--show'],stdin=subprocess.DEVNULL,stdout=out,stderr=out,start_new_session=True)
print('Carrinho Pixel instalado. Atalho e detector de sacudida ativos.')
PY
